<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td>
            <img src="<?php echo e(asset('f/avatar/' . $user->userPengirim->foto)); ?>" alt="" class="avatar">
        </td>
        <td><?php echo e($user->userPengirim->nama); ?></td>
        <td><?php echo e(Str::limit($user->pesan, 25)); ?></td>
        <td><?php echo e(Carbon\Carbon::parse($user->created_at)->diffForHumans()); ?></td>
        <td>
            <button class="btn btn-outline btn-primary btn-sm"
                onclick="document.location.href = '<?php echo e(route('chat-user', $user->userPengirim->id)); ?>'">Balas</button>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="4" class="text-center">Tidak ada pesan</td>
    </tr>
<?php endif; ?>
<?php /**PATH D:\Data\xampp\htdocs\utd-maros\resources\views/admin/chat/user-data.blade.php ENDPATH**/ ?>