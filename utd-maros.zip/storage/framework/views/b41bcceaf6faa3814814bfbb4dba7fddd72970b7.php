 <!-- Library Bundle Script -->
 <script src=<?php echo e(asset('assets/js/core/libs.min.js')); ?>></script>

 <!-- External Library Bundle Script -->
 <script src=<?php echo e(asset('assets/js/core/external.min.js')); ?>></script>

 <!-- Widgetchart Script -->
 <script src=<?php echo e(asset('assets/js/charts/widgetcharts.js')); ?>></script>

 <!-- mapchart Script -->
 <script src=<?php echo e(asset('assets/js/charts/vectore-chart.js')); ?>></script>
 <script src=<?php echo e(asset('assets/js/charts/dashboard.js')); ?>></script>

 <!-- fslightbox Script -->
 <script src=<?php echo e(asset('assets/js/plugins/fslightbox.js')); ?>></script>

 <!-- Settings Script -->
 <script src=<?php echo e(asset('assets/js/plugins/setting.js')); ?>></script>

 <!-- Form Wizard Script -->
 <script src=<?php echo e(asset('assets/js/plugins/form-wizard.js')); ?>></script>

 <!-- AOS Animation Plugin-->
 <script src=<?php echo e(asset('assets/vendor/aos/dist/aos.js')); ?>></script>

 <!-- App Script -->
 <script src=<?php echo e(asset('assets/js/hope-ui.js')); ?> defer></script>

 <?php echo $__env->yieldPushContent('js'); ?>
<?php /**PATH D:\Data\xampp\htdocs\utd-maros\resources\views/layouts/js.blade.php ENDPATH**/ ?>