<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-4 col-lg-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
            </div>
            <div class="card-body">
                <div class="form-group text-center">

                    <div class="profile-img-edit position-relative">
                        <?php if(Auth::user()->foto == 'profile.png' ): ?>
                        <img src="<?php echo e(asset('assets/images/avatars/01.png')); ?>" alt="profile-pic" class="theme-color-default-img profile-pic rounded-pill avatar-120">
                        <?php else: ?>
                        <img src="<?php echo e(asset('f/avatar/'.Auth::user()->foto )); ?>" alt="profile-pic" class="theme-color-default-img profile-pic rounded-pill avatar-120">
                        <?php endif; ?>
                    </div>

                    <div class="img-extension mt-3">
                        <div class="d-inline-block align-items-center">
                            <span><?php echo e(Auth::user()->nama); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-8 col-lg-8">
        <?php if(Session::get('success')): ?>
        <div class="alert alert-success alert-solid alert-dismissible fade show p-2 " role="alert">
            <span><?php echo e(Session::get('success')); ?></span>
            <button type="button" class="btn-close btn-close-white btn-sm pb-2" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(Session::get('fail')): ?>
        <div class="alert alert-danger alert-solid alert-dismissible fade show p-2 " role="alert">
            <span><?php echo e(Session::get('fail')); ?></span>
            <button type="button" class="btn-close btn-close-white btn-sm pb-2" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <div class="header-title">
                    <h5 class="card-title">Pengaturan Profile</h5>
                </div>
            </div>
            <div class="card-body">
                <div class="new-user-info">
                    <form action="<?php echo e(route('profile.update', Auth::user()->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">

                            <div class="form-group col-md-12">
                                <label class="form-label">Nama</label>
                                <input type="text" class="form-control" name="nama" value="<?php echo e(Auth::user()->name); ?>" autocomplete="off">
                            </div>
                            <div class="form-group col-md-12">
                                <label class="form-label">Email</label>
                                <input type="text" class="form-control" name="email" value="<?php echo e(Auth::user()->email); ?>" autocomplete="off">
                            </div>

                            <div class="form-group col-md-12">
                                <label class="form-label">Foto Profile</label>
                                <input type="file" class="form-control" name="foto">
                            </div>

                        </div>
                        <hr>
                        <h5 class="mb-3">Ganti Password</h5>
                        <?php if(Session::has('error')): ?>
                        <span class="text-danger"><?php echo e(Session::get('error')); ?></span>
                        <?php endif; ?>
                        <div class="form-group col-md-12">
                            <label class="form-label" for="rpass">Password Baru</label>
                            <input type="password" class="form-control" name="pass">
                            <p class="text-danger fw-lighter fst-italic">*kosongkan jika tidak ingin merubah password</p>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\xampp\htdocs\utd-maros\resources\views/admin/profile.blade.php ENDPATH**/ ?>