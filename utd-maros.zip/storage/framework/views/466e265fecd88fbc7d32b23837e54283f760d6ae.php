<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="message <?php echo e($pesan->pengirim == 'admin' ? 'me' : ''); ?>">
        <div class="message-item col">
            <div class="bubble">
                <span><?php echo e($pesan->pesan); ?></span>
            </div>
            <small
                class="d-block"><?php echo e($pesan->sentAt); ?></small>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Data\xampp\htdocs\utd-maros\resources\views/admin/chat/data.blade.php ENDPATH**/ ?>