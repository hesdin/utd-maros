

<?php $__env->startSection('title', 'Edit Stok Darah'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-8 col-lg-8">

            <?php if(Session::get('fail')): ?>
                <div class="alert alert-danger alert-solid alert-dismissible fade show p-2 " role="alert">
                    <span><?php echo e(Session::get('fail')); ?></span>
                    <button type="button" class="btn-close btn-close-white btn-sm pb-2" data-bs-dismiss="alert"
                        aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <div class="header-title">
                        <h5 class="card-title">Edit Data</h5>
                    </div>
                </div>
                <div class="card-body">
                    <div class="new-user-info">
                        <form action="<?php echo e(route('stok.darah.edit', $sDarah->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">

                                <div class="form-group">
                                    <label class="form-label">Tipe</label>
                                    <select name="tipe" class="form-select mb-3 shadow-none">
                                        <option selected disabled>Pilih</option>

                                        <?php $__currentLoopData = $daftarTGDarah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tGDarah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tGDarah->id); ?>"
                                                <?php echo e($sDarah->tipe_id == $tGDarah->id ? 'selected' : ''); ?>>
                                                <?php echo e($tGDarah->nm_type); ?>

                                                (<?php echo e($tGDarah->skt_type); ?>)
                                            </option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Golongan</label>
                                    <select name="golongan" class="form-select mb-3 shadow-none">
                                        <option selected disabled>Pilih</option>

                                        <?php $__currentLoopData = $daftarGDarah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gDarah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($gDarah->id); ?>"
                                                <?php echo e($sDarah->golongan_id == $gDarah->id ? 'selected' : ''); ?>>
                                                <?php echo e($gDarah->nm_golongan . ' ' . $gDarah->resus_golongan); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>

                                <div class="form-group">
                                    <label class="form-label" for="jumlah">Jumlah</label>
                                    <input type="text" class="form-control" name="jumlah" value="<?php echo e($sDarah->jumlah); ?>">
                                </div>

                            </div>

                            <button type="submit" class="btn btn-sm btn-primary">Simpan</button>
                            <a href="<?php echo e(route('stok.darah')); ?>" class="btn btn-sm btn-danger">Batal</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\xampp\htdocs\utd-maros\resources\views/admin/stok-darah-edit.blade.php ENDPATH**/ ?>