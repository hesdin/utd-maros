<!-- Library / Plugin Css Build -->
<link rel="stylesheet" href={{ asset('assets/css/core/libs.min.css') }} />

<!-- Aos Animation Css -->
<link rel="stylesheet" href={{ asset('assets/vendor/aos/dist/aos.css') }} />

<!-- Hope Ui Design System Css -->
<link rel="stylesheet" href={{ asset('assets/css/hope-ui.min.css?v=1.1.2') }} />

<!-- Custom Css -->
<link rel="stylesheet" href={{ asset('assets/css/custom.min.css?v=1.1.2') }} />

<!-- Dark Css -->
<link rel="stylesheet" href={{ asset('assets/css/dark.min.css') }} />

<!-- RTL Css -->
<link rel="stylesheet" href={{ asset('assets/css/rtl.min.css') }} />

<!-- Customizer Css -->
<link rel="stylesheet" href={{ asset('assets/css/customizer.min.css') }} />

@stack('css')
